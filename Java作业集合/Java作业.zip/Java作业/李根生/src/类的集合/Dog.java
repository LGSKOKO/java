package ��ļ���;

public class Dog extends Animal {

	private String name;
	public Dog(String name) {
		super(name);
		this.name = name;
	}

	@Override
	public String enter() {
		// TODO Auto-generated method stub
		return this.name+"������"+aBox.name+"\n";
		
	}

}
