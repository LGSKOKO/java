package ��ļ���;

public class Elephant extends Animal {

	private String name;
	public Elephant(String name) {
		super(name);
		// TODO Auto-generated constructor stub
		this.name = name;
	}

	@Override
	public String enter() {
		// TODO Auto-generated method stub
		return this.name+"������"+aBox.name+"\n";
	}

}
