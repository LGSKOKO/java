package ��ļ���;

public class Refrigerator extends Box {

	public Refrigerator(String name) {
		super(name);
		
	}

}
