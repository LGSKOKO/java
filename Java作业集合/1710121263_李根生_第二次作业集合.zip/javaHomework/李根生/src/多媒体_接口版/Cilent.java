package ��ý��_�ӿڰ�;

public class Cilent {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Computer aComputer;
		Projector aProjector;
		Screen  aScreen;
		Action  aAction;
		Openning aOpen;
		
		aAction = new Action("����");
		aComputer = new Computer("����");
		aProjector = new Projector("ͶӰ��");
		aScreen = new  Screen("��Ļ");
		aOpen = new Console("������");
		
		aAction.setAcomputer(aComputer);
		aAction.setAprojector(aProjector);
		aAction.setAscreen(aScreen);
		aAction.setAopen(aOpen);
		
		aAction.action();
		
		
		
		
		
		
	}

	

}
