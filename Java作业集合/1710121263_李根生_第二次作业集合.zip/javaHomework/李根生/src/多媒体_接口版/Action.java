package ��ý��_�ӿڰ�;

public class Action {

	private String name;
	
	public Action(String name)
	{
		super();
		this.name =name;
	}
	
	private Computer acomputer;
	private Projector aprojector;
	private Screen ascreen;
	private Openning aopen;
	
	
	
	
//get �� set ����
	public Computer getAcomputer() {
		return acomputer;
	}

	public void setAcomputer(Computer acomputer) {
		this.acomputer = acomputer;
	}

	public Projector getAprojector() {
		return aprojector;
	}

	public void setAprojector(Projector aprojector) {
		this.aprojector = aprojector;
	}

	public Screen getAscreen() {
		return ascreen;
	}

	public void setAscreen(Screen ascreen) {
		this.ascreen = ascreen;
	}
	
	
    public Openning getAopen() {
		return aopen;
	}

	public void setAopen(Openning aopen) {
		this.aopen = aopen;
	}

	//	action����
	public void action()
	{
		System.out.println(this.name);
		aopen.autoOpen();
		
		acomputer.Receive();
		acomputer.Transmit();
		
		
		aprojector.Receive();
		aprojector.Transmit();
		
		
		ascreen.Receive();
		
	}
	
}
