package if_else;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        ifElse a = new ifElse();
        a.setGrade(90);//������Ҫ���Եĳɼ�
        a.Grade();
        
	}

}
