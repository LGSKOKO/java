package è_����;

public class Action {


		private Animal aAnimal;
		private Box aBox;
		private Person aPerson;
		private String name;
		
		 public Action(String name) {
				super();
				this.name = name;
			}
	
		public Animal getaAnimal() {
			return aAnimal;
		}
	
		public void setaAnimal(Animal aAnimal) {
			this.aAnimal = aAnimal;
		}
	
		
		
		public String getName() {
			return name;
		}
	
		public void setName(String name) {
			this.name = name;
		}
	
	
		
		public Box getaBox() {
			return aBox;
		}
	
		public void setaBox(Box aBox) {
			this.aBox = aBox;
		}
	    public Person getaPerson(){
			return aPerson;
		}
		
	    public void setaPerson(Person aPerson) {
			this.aPerson = aPerson;
		}
	
		public void action(){
			System.out.println(this.getName());
			aPerson.pull();
			aBox.open();
			aAnimal.enter();    //���������
			aPerson.push();
			aBox.close();
		}
}
