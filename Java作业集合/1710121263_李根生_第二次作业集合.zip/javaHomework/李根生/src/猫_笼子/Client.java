package è_����;

public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		        Action aAction;       
				Animal aAnimal;
				Box aBox;
				Person aPerson;       
				
				
				aAction = new Action("������");
				aAnimal = new Cat("��˹è");
				aBox = new Cage("����");
				aPerson = new Person("·����");
				
				aAction.setaAnimal(aAnimal);
				aAction.setaBox(aBox);
				aAction.setaPerson(aPerson);
				
				aAnimal.setWidth(0.1);
				aAnimal.setHeight(0.4);
				aAnimal.setaBox(aBox);
				aBox.setWidth(0.6);
				aBox.setHeight(0.6);
				aAction.action();

	}

}
