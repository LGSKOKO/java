package ����������ǰ��;

public class TestRecursion {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Recursion aRecursion = new Recursion();
		aRecursion.out();
		aRecursion.f(8);
	}

}
