package ��ļ���;

public class Cat extends Animal{

	private String name;
	
	public Cat(String name) {
		super(name);
		// TODO Auto-generated constructor stub
		this.name = name;
	}

	@Override
	public String enter() {
		// TODO Auto-generated method stub
		
		 return this.name+"������"+aBox.name+"\n";
		
	}

}
