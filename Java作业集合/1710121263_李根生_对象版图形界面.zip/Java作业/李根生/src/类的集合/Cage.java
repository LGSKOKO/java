package ��ļ���;

public class Cage extends Box {

	public Cage(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}
