package ��ļ���;

public class Hole extends Box {

	public Hole(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}
